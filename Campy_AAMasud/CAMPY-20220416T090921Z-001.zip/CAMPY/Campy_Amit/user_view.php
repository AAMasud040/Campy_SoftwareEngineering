<?php session_start(); ?>

<?php
// include necessary files
require 'search_engine\by_tag.php';

require 'viewRequest\readRequest.php';
require 'viewRequest\readRequestStudent.php';
require 'viewRequest\accept.php';
require 'viewRequest\reject.php';

require 'Teacher_addRemoveStudent/readStudent.php';
require 'Teacher_addRemoveStudent/removeStudent.php';

require 'Teacher_addRemoveCourse/seeAvailableOptions.php';
require 'Teacher_addRemoveCourse/addCourse.php';
require 'Teacher_addRemoveCourse/addCourseForm.php';
require 'Teacher_addRemoveCourse/readCoursesEnrolled.php';
require 'Teacher_addRemoveCourse/readCoursesUnenrolled.php';
require 'Teacher_addRemoveCourse/removeCourse.php';

require 'viewStudents/seeAvailableOptions.php';
require 'viewStudents/readStudentList.php';

require 'Teacher_adjustWorkProfile/readProfile.php';
require 'Teacher_adjustWorkProfile/saveWorkProfile.php';

// dummy value
$user_id = $_SESSION["ID"] or header("Location: index.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Semantic UI Sidebar Types</title>
	<!--  -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Chicle&display=swap" rel="stylesheet">
	<!--  -->

	<!-- <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;500&display=swap" rel="stylesheet"> -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css" rel="stylesheet" />

	<script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js">
	</script>

	<link rel="stylesheet" href="css/user_view.css">
	<link rel="stylesheet" href="css/btn_design.css">

</head>


<body>
	<div class="ui sidebar vertical left inverted menu">
		<!-- view pending requests -->
		<a class="item">
			<form class="" action="" method="post">
				<!-- <input type="hidden" name="user_id" value="<?php echo "$user_id"; ?>"> -->
				<button type="submit" name="view_request">View Request</button>
			</form>
		</a>

        <!-- Manage Students -->
		<a class="item">
			<form class="" action="" method="post">
				<input type="hidden" name="user_id" value="<?php echo "$user_id"; ?>">
				<button type="submit" name="manage_students">Manage Students</button>
			</form>
		</a>

		<!-- Manage Courses -->
		<a class="item">
			<form action="" method="post">
				<button type="submit" name="manage_courses">Manage Courses</button>
			</form>

		</a>

		<!-- View Students -->
		<a class="item">
			<form action="" method="post">
				<button type="submit" name="view_participants">View participants</button>
			</form>

		</a>

	</div>
	<div class="ui basic icon top fixed inverted menu">
		<a id="toggle" class="item">
			<i class="sidebar icon"></i>
			Menu
		</a>
		<div class="item mid">
			<!-- <h2 class="ui inverted header">Campy</h2> -->
			<h2 class="ui inverted header"><a href="">Campy</a></h2>
		</div>
		<div class="item mid">

			<!-- search bar -->
			<div class="search-container">
				<form action="" method="post">
					<input id="search" type="search" placeholder="Search by tag ..." name="search">
					<button type="submit" name="search_tag">search</button>
				</form>
			</div>
			<!-- search bar end -->

		</div>


		<div class="ui right inverted simple dropdown item">
			<!-- Profile -->
			<img src="img/user-male.gif" alt="">
			<i class="dropdown icon"></i>
			<div class="menu">
				<!-- put options here -->
				<div class="item">
					<form class="" action="" method="post">
						<input type="hidden" name="user_id" value="<?php echo "$user_id"; ?>">
						<button type="submit" name="view_profile">view profile</button>
					</form>
				</div>

				<div class="item">
					<form class="" action="" method="post">
						<button type="submit" name="logout">log out</button>
					</form>
				</div>

			</div>
		</div>
	</div>

	<div class="pusher">
		<div class="ui container" style="padding-top: 100px;">
			<!-- enter your code here -->

			<div class="ghostbuster">
				<!-- for log out -->
				<?php if (isset($_POST['logout'])) {
					// redirect to this location
					session_destroy();
					header("Location: C:\xampp\htdocs\CAMPY\login.css");
				} ?>

				<!-- for searching by tag -->
				<?php if (isset($_POST['search_tag'])) {
					$keyword = $_POST['search'];
					search($keyword);
				} ?>

				<!-- end -->


				<!-- for view req. -->
				<?php if(isset($_POST['view_request'])) {
					readPendingRequestCourses();
				} 
				
				if(isset($_POST['view_request_student'])) {
					readRequestStudent();
				} 
				
				if(isset($_POST['accept'])) {
					acceptRequest();
				}
				
				if(isset($_POST['reject'])) {
					rejectRequest();
				}
				
				?>

				<!-- end -->


				<!-- for teacher add/remove students -->
				<?php if (isset($_POST['manage_students'])) {
					readStudents($user_id);
				} ?>

				<?php if (isset($_POST['remove_button'])) {
					removeStudent();
				} ?>

				<!-- end -->


				<!-- for teacher add/remove course -->
				<?php if (isset($_POST['manage_courses'])) {
					view_courses();
				} ?>

				<!-- called from seeAvailableOptions.php -->
				<?php if (isset($_POST['view_enrolled_courses'])) {
					view_enrolled_courses($user_id);
				} ?>

				<!-- called from seeAvailableOptions.php -->
				<?php if (isset($_POST['view_unenrolled_courses'])) {
					// echo "HI";
					view_unenrolled_courses($user_id);
				} ?>

				<?php if (isset($_POST['enroll_course'])) {
					$user_id = $_POST['user_id'];
					$course_id = $_POST['course_id'];

					Teacher_addCourseForm($user_id, $course_id);
				} ?>

				<?php if (isset($_POST['submitFromTeacher_addCourseForm'])) {
					Teacher_addCourse();
				} ?>

				<?php if (isset($_POST['unenroll_course'])) {
					Teacher_removeCourse();
				} ?>

				<!-- end -->

				<?php if (isset($_POST['view_participants'])) {
					view_courses_fromParticipants($user_id);
				} ?>

				<?php if (isset($_POST['view_participants_list'])) {
					view_participants_list();
				} ?>


				<!-- for adjusting profile -->
				<?php if (isset($_POST['view_profile'])) {
					readProfile();
				} ?>

				<?php if (isset($_POST['saveWorkProfile'])) {
					saveWorkProfile();
				} ?>
				<!-- end -->
			</div>
		</div>
	</div>



	<script>
		$("#toggle").click(function() {
			$('.ui.sidebar').sidebar('toggle');
		});
	</script>
</body>

</html>