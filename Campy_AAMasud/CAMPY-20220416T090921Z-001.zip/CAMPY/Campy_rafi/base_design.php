<?php require 'viewstudentlist.php'; ?>
<?php require 'viewteacherlist.php'; ?>
<?php require 'studentApproval.php'; ?>
<?php require 'teacherApproval.php'; ?>

<!DOCTYPE html>
<html>

<head>
	<title>Semantic UI Sidebar Types</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;500&display=swap" rel="stylesheet">
	<link href=
"https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css"
		rel="stylesheet" />

	<script src=
"https://code.jquery.com/jquery-3.1.1.min.js"
			integrity=
"sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
			crossorigin="anonymous">
	</script>
	<script src=
        "https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js">
	</script>
    <link rel="stylesheet" href="base_designcss.css">
</head>

<body>
	<div class="ui sidebar vertical left inverted menu">
		<a class="item">
			<form class="" action="" method="post">
				<button type="submit" name="button1"> View Student List </button>
			</form>  </a>

			<a class="item">
				<form class="" action="" method="post">
					<button type="submit" name="button2"> View Teacher List </button>
				</form>  </a>

				<a class="item">
					<form class="" action="" method="post">
						<button type="submit" name="button3"> Approve Students </button>
					</form>  </a>

					<a class="item">
						<form class="" action="" method="post">
							<button type="submit" name="button4"> Approve Teachers </button>
						</form>  </a>

	</div>
	<div class="ui basic icon top fixed inverted menu" >
        <a id="toggle" class="item">
            <i class="sidebar icon"></i>
            Menu
        </a>
        <div class="item mid" ><h2 class="ui inverted header">Campy</h2></div>
        <div class="ui right inverted simple dropdown item">
            Dropdown
            <i class="dropdown icon"></i>
            <div class="menu">
              <div class="item">Choice 1</div>
              <div class="item">Choice 2</div>
              <div class="item">Choice 3</div>
              <div class="item">Choice 3</div>
            </div>
        </div>
    </div>

    <div class="pusher">
        <div class="ui container" style="padding-top: 100px;">

						<?php if (isset($_POST['button1'])) {
							// code...
							viewStudent();
						} ?>

						<?php if (isset($_POST['button2'])) {
							// code...
							viewTeacher();
						} ?>

						<?php if (isset($_POST['button3'])) {
							// code...
							studentApproval();
						} ?>

						<?php if (isset($_POST['button4'])) {
							// code...
							teacherApproval();
						}
						$conn = mysqli_connect("localhost" , "root", "" , "campyv4");
				    if ($conn-> connect_error) {
				        die("Connection failed:" . $conn-> connect_error);
				      }

				    if(isset($_POST['approve1'])) {
				      $user_id = $_POST['user_id'];

				      $sql2 = "UPDATE student SET approval = 1 WHERE user_id = '$user_id'";
				      $result2 = $conn-> query($sql2);
				    }

				    if(isset($_POST['deny1'])) {
				      $user_id = $_POST['user_id'];

				      $sql3 = "DELETE FROM student WHERE user_id = '$user_id'";
				      $result3 = $conn-> query($sql3);
				    }

						if(isset($_POST['approve2'])) {
				      $user_id = $_POST['user_id'];

				      $sql2 = "UPDATE teacher SET approval = 1 WHERE user_id = '$user_id'";
				      $result2 = $conn-> query($sql2);
				    }

				    if(isset($_POST['deny2'])) {
				      $user_id = $_POST['user_id'];

				      $sql3 = "DELETE FROM teacher WHERE user_id = '$user_id'";
				      $result3 = $conn-> query($sql3);

				    }
						 ?>
				</div>
    </div>



	<script>
        $("#toggle").click(function(){
            $('.ui.sidebar').sidebar('toggle');
        });

	</script>
</body>
</html>