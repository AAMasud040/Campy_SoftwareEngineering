<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Campy: Log In</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bubblegum+Sans&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="login.css">
</head>

<body>
  <div id="outer_layer">
    <div id="main">
      <div class="logo">
        <h1>Campy</h1>

      </div>
      <div class="info">
        <form class="" action="" method="post">
          <input type="text" name="username" placeholder="username" required>
          <input type="password" name="password" placeholder="password" required>

          <button type="submit" name="logIn">Log In</button>

        </form>
      </div>
    </div>
  </div>
  
  <?php if (isset($_POST['logIn']) and strcmp(trim($_POST['username']), 'teacher')==0) {
    $_SESSION["ID"] = 1;
    header("Location: Campy_Amit\user_view.php");
  } 
  
  if (isset($_POST['logIn']) and strcmp(trim($_POST['username']), 'admin')==0) {
    header("Location: Campy_rafi\base_design.php");
  }

  if (isset($_POST['logIn']) and strcmp(trim($_POST['username']), 'super')==0) {
    header("Location: Campy_Anamul\s_admin.php");
  }
  ?>

</body>

</html>